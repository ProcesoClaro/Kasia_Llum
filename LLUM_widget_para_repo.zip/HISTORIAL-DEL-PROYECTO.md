# COANFI Chat — Historial del proyecto y guía de relevo

**Cliente:** COANFI (inmobiliaria). Asistente virtual "KasIA".
**Agencia:** ProcesoClaro.
**Periodo:** 26/06/2026 – 26/08/2026 (última entrega).
**Repositorio de este archivo:** https://github.com/ProcesoClaro/coanfi (privado).
**Actualizado:** 24/09/2026.

Este documento existe para que cualquier persona (Javi, o quien venga después) pueda coger el relevo del proyecto sin depender de nadie. Explica qué es el producto, cómo ha evolucionado versión a versión, dónde está cada cosa y cómo se modifica y se vuelve a entregar.

---

## Índice

1. [Qué es el producto](#1-qué-es-el-producto)
2. [Estado actual (lo que está en producción)](#2-estado-actual-lo-que-está-en-producción)
3. [Mapa de carpetas y repositorios](#3-mapa-de-carpetas-y-repositorios)
4. [Historial de versiones](#4-historial-de-versiones)
5. [Arquitectura técnica](#5-arquitectura-técnica)
6. [Contrato con el backend (n8n)](#6-contrato-con-el-backend-n8n)
7. [Cómo modificar y volver a entregar](#7-cómo-modificar-y-volver-a-entregar)
8. [Problemas conocidos y lecciones aprendidas](#8-problemas-conocidos-y-lecciones-aprendidas)
9. [Checklist de relevo](#9-checklist-de-relevo)

---

## 1. Qué es el producto

Un widget de chat flotante (burbuja en la esquina inferior derecha) que se incrusta en la web del cliente y conversa con un asistente de IA llamado **KasIA**. La lógica conversacional no vive en el widget: el widget envía cada mensaje a un **webhook de n8n** y pinta la respuesta.

Funcionalidades del widget:

- Consentimiento RGPD antes de conversar (botón "Acepto" → "✓ Aceptado").
- Feedback 👍 / 👎 en cada respuesta del asistente.
- Botones de respuesta rápida y tarjetas (cards) que el backend puede devolver.
- Cierre automático de la conversación cuando el backend lo indica (por ejemplo, tras agendar una cita).
- Nombre del asistente en negrita cuando aparece en las respuestas.
- Aislamiento total del CSS de la web anfitriona mediante Shadow DOM.
- Personalización de nombre, avatar, logo, colores, textos y URLs.

Se entrega en **dos formatos que contienen el mismo chat**. El cliente instala solo uno:

| Formato | Para qué web | Paquete |
|---|---|---|
| Plugin WordPress | Webs WordPress | `coanfi-chat.zip` (se sube desde Plugins → Añadir nuevo) |
| Widget HTML | Cualquier otra web (HTML, Plesk, otro CMS, GTM) | `coanfi-chat-html.zip` (subir archivos + pegar snippet antes de `</body>`) |

---

## 2. Estado actual (lo que está en producción)

| Dato | Valor |
|---|---|
| Entrega vigente | `COANFI Chat - VERSION FINAL V2/` (26/08/2026) |
| Versión plugin WordPress | **4.0.2** |
| Versión widget HTML | **9.0.2** (parámetro de caché `?v=902`) |
| Web del cliente con el widget instalado | arqueriasvelvet.com (variante HTML) |
| Backend | n8n en Elestio: `https://n8n-automation-u76494.vm.elestio.app/webhook/…` |
| Webhooks | `chat-velvet` (conversación), `feedback` (👍/👎), `event` (apertura del chat) |
| Política de privacidad enlazada | https://www.coanfi.com/politica-privacidad/ |
| Compatibilidad | Chrome/Edge 99+, Safari/iOS 15.4+, Firefox 97+. En navegadores anteriores el chat no se muestra y no afecta a la web. |

**Regla de oro:** si hay que tocar algo, se parte siempre de `COANFI Chat - VERSION FINAL V2/2 - Codigo fuente/`. Todo lo demás son entregas históricas congeladas.

### 2.1 Segunda promoción: LLUM Fusión (Sagunto) — desde 24/09/2026

| Dato | Valor |
|---|---|
| Entrega | `COANFI Chat - LLUM Fusion V1/` |
| Versión widget | **10.0.0** (`?v=1000`) · plugin 4.1.0 |
| Fase 1 (7/10/2026) | Página del QR a pantalla completa: https://www.llumfusion.com/kasia.html (`kasia-llumfusion-web.zip`: `kasia.html` + carpeta `kasia/` en la raíz). Tablet del stand: https://www.llumfusion.com/kasia.html?quiosco=1 |
| Fase 2 (26/10/2026) | Burbuja en la landing: `kasia-llum-burbuja-fase2.zip` (reutiliza `/kasia/`) |
| Webhook | `chat-llum` (workflow propio en n8n; comparte Supabase, Redis con prefijo `llum:` y ActiveCampaign) |

El código 10.0.0 es compatible hacia atrás: sin las claves nuevas se comporta como 9.0.2. **Para cambios que afecten a las dos promociones, partir de `COANFI Chat - LLUM Fusion V1/2 - Codigo fuente/`** (es la versión más reciente) y entregar a Velvet solo si hace falta.

---

## 3. Mapa de carpetas y repositorios

### 3.1 Repositorios en GitHub (organización ProcesoClaro, ambos privados)

| Repo | Qué es | Rama a usar |
|---|---|---|
| **coanfi** | Este archivo completo: todas las entregas históricas + archivos del proyecto. Es la fuente de verdad del entregable. | `main` |
| **coanfi-chat-buddy** | La app original creada en Lovable. Sirve como entorno de diseño y pruebas visuales. **No es el entregable.** Está enlazado dentro de `coanfi` como submódulo git. | `clean` (la rama `main` es la que sincroniza Lovable; `clean` es la que limpiamos a mano y ya no tiene rastros de Lovable) |

Para clonar todo de una vez:

```bash
git clone --recurse-submodules https://github.com/ProcesoClaro/coanfi.git
```

### 3.2 Estructura de la carpeta raíz

```
COANFI - Github/
├── HISTORIAL-DEL-PROYECTO.md       ← este documento
├── sincronizar.sh                  ← commit + push de todo (raíz y submódulo)
├── COANFI Chat - VERSION FINAL V2/ ← ENTREGA VIGENTE (26/08/2026)
│   ├── 1 - Entrega al cliente/     ← los dos ZIP que se envían al cliente
│   ├── 2 - Codigo fuente/          ← código para modificar y recompilar
│   ├── Email para el cliente.txt   ← borrador del aviso sobre el fix de móvil
│   └── LEEME.txt
├── COANFI Chat - VERSION FINAL/    ← entrega anterior (24/08), mismo código, manuales antiguos
├── V10/                            ← solo los ZIP y PDF de la entrega del 24/08
├── Plugin WordPress/  … V4/        ← histórico del plugin (1.0.0 → 4.0.2)
├── Widget HTML/  … V9/             ← histórico del widget HTML (1 → 9.0.2)
└── Archivos del proyecto/
    ├── coanfi-chat-buddy/          ← submódulo: app Lovable (rama clean)
    └── GUIA-LOVABLE-A-PLUGIN-WORDPRESS.md  ← guía de cómo se pasó de Lovable a plugin
```

### 3.3 Contenido de `2 - Codigo fuente/` (la entrega vigente)

| Carpeta / archivo | Qué contiene |
|---|---|
| `widget/` | Código React del chat. **Única fuente de verdad.** `src/main.tsx` monta el Shadow DOM, aplica el blindaje de teclado y la puerta de compatibilidad de navegadores. `src/config.ts` define la configuración runtime. `src/components/chat/` es la interfaz. `src/hooks/useChat.ts` es toda la lógica de conversación. `postbuild-compat.js` convierte colores oklch → hex y rem → px tras compilar. |
| `plugin/coanfi-chat/` | Plugin WordPress en PHP. `coanfi-chat.php` tiene la página de ajustes y la inyección del script. `assets/coanfi-chat.js` es el bundle compilado: **no editarlo a mano**, se regenera con el build. `readme.txt` lleva el changelog oficial. |
| `html-snippet/` | `snippet.html` (lo que el cliente pega antes de `</body>`), `demo.html` para probar en local, y las imágenes `kasia-avatar.png` y `coanfi-isotipo.jpg`. |
| `docs/` | Los tres manuales en Markdown (plugin, widget HTML, instrucciones de instalación) y `md2pdf.py` para regenerar los PDF con Chrome. |
| `build.sh` | Compila el widget, deja el bundle en `plugin/coanfi-chat/assets/` y genera `dist/coanfi-chat.zip`. |

---

## 4. Historial de versiones

### 4.1 Línea temporal resumida

| Fecha | Hito |
|---|---|
| 26/06/2026 | Arranca el proyecto en Lovable (repo `coanfi-chat-buddy`). Asistente llamado inicialmente "COANF_IA". Se conecta Supabase y se añade el widget de reservas de n8n. |
| 13/07/2026 | Renombrado a "KasiA". Mensaje de bienvenida, soft-close (cierre suave de conversación) y nombre en negrita. |
| 15/07/2026 | **Primera entrega:** Plugin WordPress 1.0.0 y Widget HTML V1. El mismo día salen V2 de ambos (KasiA + cierre automático). Se deja de enviar el nombre del usuario al webhook. Widget HTML V3 y V4. |
| 16/07/2026 | Widget HTML V5 y V6 (avatar PNG e isotipo de Coanfi en cabecera). |
| 20/07/2026 | Trabajo de diseño en Lovable: icono → avatar KasiA, estilo "halo cristalino" (revertido después). |
| 22/07/2026 | Plugin WordPress 3.0.0 (V3) y Widget HTML V7 y V8. Nuevo texto de bienvenida. |
| 13/08/2026 | En Lovable: chat con `sessionId`. |
| 20/08/2026 | Endpoints de producción del cliente (Elestio). Se crea la rama `clean` sin rastros de Lovable. Plugin 4.0.0. |
| 24/08/2026 | Plugin 4.0.1: botón "✓ Aceptado" y blindaje de teclado (bug de los espacios en arqueriasvelvet.com). Entrega **V10** y **VERSION FINAL** con plugin 4.0.2 / widget 9.0.2. |
| 26/08/2026 | **VERSION FINAL V2**: fixes de móvil (tamaño encogido, burbuja sobre el botón de enviar, teclado iOS). Manuales actualizados. Email de aviso al cliente. |
| 24/09/2026 | Se sube todo el histórico al repo privado `ProcesoClaro/coanfi`. |
| 24/09/2026 | **LLUM Fusión V1** (widget 10.0.0 / plugin 4.1.0): segunda promoción (Sagunto). Modos pantalla completa (QR) y quiosco (tablet del stand), clave `PROMOCION`. Webhook `chat-llum`. Velvet sigue en la V2. |

### 4.2 Plugin WordPress (changelog oficial, de `readme.txt`)

| Versión | Carpeta | Fecha | Cambios |
|---|---|---|---|
| **1.0.0** | `Plugin WordPress/` | 15/07/2026 | Primera versión. Asistente "COANF_IA". Widget flotante, consentimiento RGPD, feedback 👍/👎, personalización, shortcode `[coanfi_chat]`, Shadow DOM. |
| **2.0.0** | `Plugin WordPress V2/` | 15/07/2026 | Asistente pasa a "KasiA" (nombre, bienvenida, avatar). Cierre automático de conversación cuando el webhook lo indica. Botones de respuesta rápida tipo botón o enlace con `target`. Nuevo campo "texto al cerrar". Nombre del asistente en negrita. Ya no se envía el nombre del usuario al webhook. |
| **3.0.0** | `Plugin WordPress V3/` | 22/07/2026 | Avatar y logo de KasIA incluidos en el plugin. Nombre por defecto "KasIA" (I mayúscula). Negrita del nombre case-insensitive. |
| **4.0.0** | `Plugin WordPress V4/` | 20/08/2026 | `sessionId` nuevo por conversación, generado al aceptar la política; primer mensaje con `new_chat: true`. Webhooks de producción preconfigurados (editables desde Ajustes). Isotipo de Coanfi en la cabecera. Avatar PNG con transparencia. |
| **4.0.1** | `Plugin WordPress V4/` | 24/08/2026 | Compatibilidad ampliada (Chrome/Edge 99+, Safari/iOS 15.4+, Firefox 97+). Botón "Acepto" → "✓ Aceptado" en verde y desactivado tras aceptar. Blindaje de teclado frente a librerías de la plantilla anfitriona (SmoothScroll.js) que cancelaban espacio y flechas. |
| **4.0.2** | `Plugin WordPress V4/` y `VERSION FINAL V2` | 26/08/2026 | Tamaño en móvil inmune al font-size base de la plantilla (medidas en px). Burbuja flotante oculta en móvil con el chat abierto. Ventana ajustada al teclado virtual de iOS. Sin auto-zoom en iOS (letra a 16 px). |

Nota: la carpeta `Plugin WordPress V4/` contiene el mismo código que `VERSION FINAL V2/2 - Codigo fuente/` (solo le faltan `docs/` y `html-snippet/`).

### 4.3 Widget HTML (qué cambió en cada carpeta)

El bundle `coanfi-chat.js` es el mismo que el del plugin de la misma fecha. Lo que cambia entre carpetas es el snippet de configuración, las imágenes y los manuales.

| Carpeta | Fecha | Cambios respecto a la anterior |
|---|---|---|
| `Widget HTML/` | 15/07 | Primera versión. Asistente "COANF_IA". Solo `Manual de uso`. |
| `Widget HTML V2/` | 15/07 | Asistente "KasiA". Nuevo `CLOSE_TEXT`. Bundle actualizado (= plugin 2.0.0). |
| `Widget HTML V3/` | 15/07 | "KasIA". Se añade el avatar como archivo (`kasia-avatar.jpg`) y el manual `Instrucciones de instalacion`. |
| `Widget HTML V4/` | 15/07 | Snippet **preconfigurado con los webhooks** (el cliente ya no rellena nada). Mismo bundle que V3. |
| `Widget HTML V5/` | 16/07 | Avatar en PNG (`kasia-avatar.png`) e isotipo de Coanfi (`coanfi-isotipo.jpg`) en la cabecera. Mismo bundle. |
| `Widget HTML V6/` | 16/07 | Bundle actualizado (ajustes visuales). Snippet igual. |
| `Widget HTML V7/` | 22/07 | Nuevo texto de bienvenida y tooltip: "Hola, soy KasIA, tu asistente inmobiliario, ¿Necesitas ayuda?". Bundle = plugin 3.0.0. |
| `Widget HTML V8/` | 22/07 | Bundle actualizado (optimización de tamaño). Snippet igual. Webhooks aún en `procn8nwh.procesoclaro.com` (n8n de ProcesoClaro). |
| `Widget HTML V9/` | 24–26/08 | **Widget 9.0.2.** Webhooks de producción en Elestio. Script con `?v=902` para invalidar caché. Bundle = plugin 4.0.2. |

### 4.4 Entregas empaquetadas

| Carpeta | Fecha | Contenido |
|---|---|---|
| `V10/` | 24/08 | Solo los ZIP y PDF para el cliente (plugin 4.0.2 + widget 9.0.2, primera revisión). |
| `COANFI Chat - VERSION FINAL/` | 24/08 | ZIP para el cliente + código fuente completo. Manuales sin la sección de convivencia con la plantilla. |
| `COANFI Chat - VERSION FINAL V2/` | 26/08 | **Vigente.** Igual que la anterior pero con el código 4.0.2 definitivo, manuales con la sección "Convivencia con la plantilla de tu web" y el email de aviso al cliente. |

### 4.5 Historial git de `coanfi-chat-buddy` (rama `clean`)

Los commits con mensaje "Changes", "Work in progress", "Lovable update" y "Update plan" los genera Lovable automáticamente. Los que importan:

| Fecha | Commit | Qué hizo |
|---|---|---|
| 26/06 | `4442cfc` | Añadido widget n8n de reservas. |
| 26/06 | `eef8932` | Asistente renombrada a "COANF_IA". |
| 26/06 | `620a7c0` | Conexión con Supabase. |
| 26/06 | `ef2f33a` | URLs de webhook. |
| 13/07 | `a2feb4d` | Soft-close y nombres. |
| 13/07 | `0425f3e` | Mensaje de bienvenida. |
| 13/07 | `541ac45` | KasiA en negrita. |
| 15/07 | `608e8d1` | Se elimina el campo `name` del POST. |
| 20/07 | `dbbd7cc` | Texto de KasIA. |
| 20/07 | `27a7269` | Icono → avatar KasiA. |
| 20/07 | `a7eff7c` / `bd9d914` | Estilo "halo cristalino", revertido al commit anterior. |
| 13/08 | `72148d5` | Chat con `sessionId`. |
| 20/08 | `be88829` | Endpoints del cliente (Elestio). |
| 20/08 | `ee34c46` | **Nace la rama `clean`:** elimina todo rastro de Lovable y sustituye assets remotos por imágenes locales. |
| 24/08 | `5ef699b` | Botón "✓ Aceptado" verde y desactivado. |
| 26/08 | `f31ff6a` | Fixes de móvil: launcher oculto con el chat abierto, ajuste al teclado (`visualViewport`), input a 16 px. |

---

## 5. Arquitectura técnica

### 5.1 Dos mundos distintos

Son dos productos con dos stacks. No es una migración, es una extracción. La guía completa está en `Archivos del proyecto/GUIA-LOVABLE-A-PLUGIN-WORDPRESS.md`.

| | App Lovable (`coanfi-chat-buddy`) | Widget entregable (`2 - Codigo fuente/widget/`) |
|---|---|---|
| Papel | Entorno de diseño y pruebas | Lo que se entrega al cliente |
| Framework | TanStack Start (SSR) + TanStack Router | React 19 mínimo, sin router |
| Build | Vite 8 + Nitro 3 | Vite en formato IIFE → un solo `coanfi-chat.js` (~230 KB) |
| Estilos | Tailwind CSS 4 + shadcn/ui | Tailwind 4 compilado dentro del Shadow DOM, post-procesado a hex y px |
| Backend | Supabase + n8n | Solo n8n vía webhooks |
| Gestor | Bun | Bun (npm como alternativa) |

**Importante:** los componentes del chat se mantienen sincronizados **a mano** entre `coanfi-chat-buddy/src` (rama `clean`) y `widget/src`. No hay automatismo. Si cambias uno, cambia el otro.

### 5.2 Cómo se carga el widget

1. La web define `window.COANFI_CHAT_CONFIG` (el plugin lo inyecta con `wp_localize_script`; en HTML lo pone el snippet).
2. Se carga `coanfi-chat.js`. `main.tsx` comprueba la compatibilidad del navegador; si no pasa, no monta nada.
3. Crea un `<div>` con Shadow DOM, inyecta el CSS dentro y monta React.
4. `config.ts` fusiona los valores por defecto con los inyectados.

### 5.3 Claves de configuración

Las mismas en el plugin (Ajustes → COANFI Chat) y en el snippet HTML:

| Clave | Uso |
|---|---|
| `WEBHOOK_URL` | Webhook de conversación (obligatorio). |
| `FEEDBACK_URL` | Webhook de feedback 👍/👎. |
| `EVENT_URL` | Webhook de eventos (apertura del chat). |
| `DISPLAY_MODE` | 10.0.0 · `"bubble"` (por defecto) o `"fullscreen"` (QR). Por URL: `?modo=pantalla`. |
| `KIOSK`, `KIOSK_IDLE_SECONDS`, `KIOSK_WARNING_SECONDS` | 10.0.0 · Quiosco: "Nueva conversación" y reinicio por inactividad (180 s, aviso 20 s). Por URL: `?quiosco=1`. |
| `PROMOCION` | 10.0.0 · Se envía al webhook como `promocion` y separa las claves de `sessionStorage`. |
| `HEADER_SUBTITLE` | 10.0.0 · Subtítulo de la cabecera (por defecto "En línea"). |
| `ASSISTANT_NAME` | Nombre del asistente ("KasIA"). |
| `ASSISTANT_AVATAR` | Imagen junto a cada mensaje. |
| `LOGO_URL` | Isotipo en la cabecera. |
| `BRAND_COLOR` / `BRAND_COLOR_DARK` | Colores de marca (`#1E5BFF` / `#1646C7`). |
| `PRIVACY_URL` | Enlace de la política de privacidad. |
| `WELCOME`, `TOOLTIP_TEXT`, `CONSENT_TEXT`, `ASK_NAME_TEXT`, `CLOSE_TEXT` | Textos. |

El plugin añade además `enabled` y `mode` (automático en todas las páginas o mediante shortcode `[coanfi_chat]`).

---

## 6. Contrato con el backend (n8n)

Los flujos de n8n **no están en este repositorio**. Viven en la instancia de Elestio del cliente. Lo que sí está definido aquí es lo que el widget envía y espera (`widget/src/hooks/useChat.ts`).

### 6.1 Conversación → `WEBHOOK_URL` (POST JSON)

```json
{
  "sessionId": "uuid generado al aceptar la política",
  "message": "texto del usuario",
  "name": null,
  "consent": true,
  "new_chat": true
}
```

- `new_chat: true` solo viaja en el primer mensaje de cada conversación (y se repite si ese primer POST falla).
- El `sessionId` se guarda en `sessionStorage`; cada conversación nueva genera uno distinto.

Respuesta esperada:

```json
{
  "respuesta": "texto del asistente",
  "buttons": [{ "label": "…", "action": "…", "close_on_click": true }],
  "cards": [ … ],
  "skipped": false
}
```

- `skipped: true` indica un mensaje intermedio (debounce en servidor): el widget no pinta nada.
- Si no llega `respuesta`, `buttons` ni `cards`, no se pinta mensaje.
- Ante error HTTP o de red el widget muestra "Ups, ha habido un problema. ¿Puedes repetirlo?".

### 6.2 Feedback → `FEEDBACK_URL` (POST JSON)

```json
{
  "sessionId": "…",
  "turnId": "id del mensaje del asistente",
  "rating": "up | down",
  "mensaje": "lo que escribió el usuario",
  "respuesta": "lo que contestó el asistente"
}
```

### 6.3 Evento de apertura → `EVENT_URL` (POST JSON)

Se envía una sola vez por sesión al abrir el chat:

```json
{ "sessionId": "…", "evento": "apertura_chatbot", "clientId": "…" }
```

---

## 7. Cómo modificar y volver a entregar

### 7.1 Requisitos

- Git.
- Bun (https://bun.sh). Si no, npm.
- `zip` en la línea de comandos.
- Google Chrome (solo para regenerar los PDF de los manuales con `docs/md2pdf.py`).

### 7.2 Flujo de trabajo

1. Clonar el repo con submódulos (ver sección 3.1).
2. Trabajar en `COANFI Chat - VERSION FINAL V2/2 - Codigo fuente/widget/src/`.
3. Compilar y empaquetar el plugin:
   ```bash
   cd "COANFI Chat - VERSION FINAL V2/2 - Codigo fuente"
   bash build.sh
   ```
   Deja el bundle en `plugin/coanfi-chat/assets/coanfi-chat.js` y genera `dist/coanfi-chat.zip`.
4. Para la variante HTML: copiar ese `coanfi-chat.js` junto a los archivos de `html-snippet/` y comprimirlo todo como `coanfi-chat-html.zip`.
5. Probar en local abriendo `html-snippet/demo.html` (ajustar rutas si hace falta).
6. **Si cambia la versión**, actualizar en tres sitios:
   - `plugin/coanfi-chat/coanfi-chat.php`: cabecera `Version:` y constante `COANFI_CHAT_VERSION` (invalida la caché en WordPress).
   - `plugin/coanfi-chat/readme.txt`: `Stable tag` y nuevo bloque en el changelog.
   - `html-snippet/snippet.html`: el parámetro `?v=` del script (invalida la caché en el navegador).
7. Actualizar los manuales en `docs/*.md` y regenerar los PDF con `python3 docs/md2pdf.py`.
8. Replicar los cambios de componentes en `coanfi-chat-buddy` (rama `clean`) si afectan a la interfaz.
9. Crear una nueva carpeta de entrega (por ejemplo `COANFI Chat - VERSION FINAL V3/`) copiando la estructura de la V2. No sobrescribir las anteriores.
10. Subir todo a GitHub desde la raíz:
    ```bash
    bash sincronizar.sh "Descripción del cambio"
    ```

### 7.3 Actualizar la web del cliente que ya tiene el widget (arqueriasvelvet.com)

1. Sustituir `/js/coanfi-chat.js` en su servidor por el del ZIP nuevo.
2. Cambiar la etiqueta del script para que lleve el nuevo `?v=`:
   ```html
   <script src="/js/coanfi-chat.js?v=902"></script>
   ```
   Sin cambiar el `?v=` los navegadores seguirán usando la versión cacheada.

### 7.4 Configurar los webhooks

Los tres webhooks de producción vienen preconfigurados en el plugin y en el snippet. Si el cliente cambia de instancia de n8n, basta con cambiarlos en Ajustes → COANFI Chat (WordPress) o en `window.COANFI_CHAT_CONFIG` del snippet. No hace falta recompilar.

---

## 8. Problemas conocidos y lecciones aprendidas

**Espacios que no se escribían en el chat (24/08).** La plantilla de arqueriasvelvet.com usa SmoothScroll.js, que cancela la tecla espacio y las flechas a nivel de `document`. Por el retargeting de eventos del Shadow DOM, esa librería no detectaba que el usuario estaba escribiendo dentro del chat. Solución: las teclas que nacen en el input ya no salen del widget (`main.tsx`).

**Widget encogido en móvil (26/08).** La misma plantilla reduce el `font-size` base del `html` (14 px en escritorio, 11–13 px en móvil). Como Tailwind usa `rem`, el widget heredaba ese tamaño. Solución: `postbuild-compat.js` convierte todos los `rem` a `px` en el build. El widget ya no depende de la plantilla. No se pidió al cliente que tocara su CSS porque afectaría a toda su web.

**Burbuja sobre el botón de enviar y teclado iOS.** En móvil, con el chat abierto, la burbuja flotante se oculta y se usa la X de la cabecera. La ventana se ajusta al `visualViewport` para que la caja de escritura quede visible con el teclado desplegado. El input va a 16 px para evitar el auto-zoom de iOS.

**Colores oklch.** Tailwind 4 genera colores en `oklch`, que no soportan navegadores anteriores a 2023. `postbuild-compat.js` los convierte a hex. Por eso la compatibilidad llega a Chrome/Edge 99+, Safari 15.4+ y Firefox 97+.

**Caché del navegador.** Cada entrega del widget HTML debe cambiar el `?v=` del script. Si no, el cliente verá la versión antigua y pensará que el fix no funciona.

**Pulsaciones repetidas en "Acepto".** Antes de 4.0.1, pulsar varias veces regeneraba el `sessionId`. Ahora el botón se desactiva tras aceptar.

**No instalar plugin y snippet en la misma web.** Se montarían dos widgets.

**Lovable.** No intentar convertir la app de Lovable en plugin. Se extrajeron los componentes a un proyecto React mínimo. La guía de `Archivos del proyecto/` documenta el proceso completo por si se repite en otro cliente.

---

## 9. Checklist de relevo

- [ ] Tengo acceso a la organización **ProcesoClaro** en GitHub (repos `coanfi` y `coanfi-chat-buddy`).
- [ ] He clonado `coanfi` con `--recurse-submodules` y el submódulo está en la rama `clean`.
- [ ] Tengo acceso a la instancia de n8n del cliente en Elestio (los flujos no están en el repo).
- [ ] He ejecutado `bash build.sh` en `VERSION FINAL V2/2 - Codigo fuente/` y genera `dist/coanfi-chat.zip` sin errores.
- [ ] He abierto `html-snippet/demo.html` y el chat responde contra el webhook de producción.
- [ ] He leído `Archivos del proyecto/GUIA-LOVABLE-A-PLUGIN-WORDPRESS.md`.
- [ ] Sé que la única fuente de verdad del código es `VERSION FINAL V2/2 - Codigo fuente/widget/` y que el resto de carpetas son histórico congelado.
- [ ] Sé que cada entrega nueva va en una carpeta nueva y se sube con `bash sincronizar.sh`.

---

*Documento generado a partir de los LEEME, changelogs, manuales y el historial git del proyecto. Si algo de aquí deja de ser cierto, actualízalo: este archivo es parte del repo.*
